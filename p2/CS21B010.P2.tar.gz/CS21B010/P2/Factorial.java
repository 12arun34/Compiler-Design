class Factorial{
    public static void main(String[] a){
        System.out.println(1);
    }
}

class Fac {
 int x;
   public int ComputeFac(int num_aux )
	    {
		  int t ;
		  //int num_aux;
		  return num_aux;
    }
}

class Fac1 extends Fac{
int z;
public int ComputeFac1(int num )
	    {
	       int tt;
		  //int num_aux;
		  return num;
    }

}

